﻿using System;
using System.Collections.Generic;

namespace CompanyGroup.WebClient.Models
{
    public class SignInRequest
    {
        public string UserName { get; set; }

        public string Password { get; set; }

    }
}
