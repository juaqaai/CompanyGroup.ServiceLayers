﻿using System;
using System.Collections.Generic;

namespace CompanyGroup.WebClient.Models
{
    public class EmptyResponse : CompanyGroup.Dto.ServiceResponse.Empty
    {
    }
}
