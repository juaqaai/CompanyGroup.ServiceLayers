﻿using System;
using System.Collections.Generic;

namespace CompanyGroup.WebClient.Models
{
    public class SignOutRequest
    {
        public string ObjectId { get; set; }
    }
}
