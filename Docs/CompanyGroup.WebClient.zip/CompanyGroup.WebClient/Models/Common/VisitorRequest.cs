﻿using System;
using System.Collections.Generic;

namespace CompanyGroup.WebClient.Models
{
    /// <summary>
    /// felhasználó 
    /// </summary>
    public class VisitorRequest
    {
        public string VisitorId { get; set; }
    }

}
