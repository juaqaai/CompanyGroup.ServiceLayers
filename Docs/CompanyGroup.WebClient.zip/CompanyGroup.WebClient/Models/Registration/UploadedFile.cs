﻿using System;
using System.Collections.Generic;

namespace CompanyGroup.WebClient.Models
{
    public class UploadedFile
    {
            public string Name { get; set; }

            public int Length { get; set; }

            public string Type { get; set; }
    }
}
