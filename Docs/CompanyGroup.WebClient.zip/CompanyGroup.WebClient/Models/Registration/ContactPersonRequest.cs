﻿using System;
using System.Collections.Generic;

namespace CompanyGroup.WebClient.Models
{
    public class ContactPersonRequest : CompanyGroup.WebClient.Models.ContactPerson
    {
    }
}
