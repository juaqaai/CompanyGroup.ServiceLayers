﻿using System;
using System.Collections.Generic;

namespace CompanyGroup.WebClient.Models
{
    public class ChangeCurrencyRequest
    {
        public string Currency { get; set; }
    }
}