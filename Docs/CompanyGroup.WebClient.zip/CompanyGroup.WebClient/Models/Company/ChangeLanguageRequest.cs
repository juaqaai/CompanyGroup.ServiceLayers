﻿using System;
using System.Collections.Generic;

namespace CompanyGroup.WebClient.Models
{
    public class ChangeLanguageRequest
    {
        public string Language { get; set; }
    }
}