﻿using System;
using System.Collections.Generic;

namespace CompanyGroup.WebClient.Models
{
    public class AddCart
    {
        //AddCart()
        //{
        //    this.Name = String.Empty;
        //}

        /// <summary>
        /// kosár neve
        /// </summary>
        public string Name { get; set; }
    }
}
