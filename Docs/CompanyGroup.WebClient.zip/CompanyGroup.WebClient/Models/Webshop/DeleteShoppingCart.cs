﻿using System;

namespace CompanyGroup.WebClient.Models
{
    public class DeleteShoppingCart 
    {
        /// <summary>
        /// kosár azonosító
        /// </summary>
        public string CartId { get; set; }
    }

}
