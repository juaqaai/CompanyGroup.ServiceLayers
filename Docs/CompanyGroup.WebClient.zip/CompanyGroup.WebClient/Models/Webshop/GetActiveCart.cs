﻿using System;
using System.Collections.Generic;

namespace CompanyGroup.WebClient.Models
{
    /// <summary>
    /// látogatóhoz tartozó összes kosár lekérdezés adatait összefogó POCO
    /// </summary>
    public class GetActiveCart
    {
    }
}
