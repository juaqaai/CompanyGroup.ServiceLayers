﻿using System;
using System.Collections.Generic;

namespace CompanyGroup.WebClient.Models
{
    public class FirstLevelCategories : List<StructureItem> { }
}
