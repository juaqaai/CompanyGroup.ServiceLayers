﻿using System;
using System.Collections.Generic;

namespace CompanyGroup.WebClient.Models
{
    public class RemoveCart
    {
        /// <summary>
        /// kosár azonosító
        /// </summary>
        public int CartId { get; set; }
    }
}
