﻿using System;
using System.Collections.Generic;

namespace CompanyGroup.WebClient.Models
{
    public class ThirdLevelCategories : List<StructureItem> { }
}
