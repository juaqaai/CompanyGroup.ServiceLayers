﻿using System;
using System.Collections.Generic;

namespace CompanyGroup.WebClient.Models
{
    public class SecondLevelCategories : List<StructureItem> { }
}
